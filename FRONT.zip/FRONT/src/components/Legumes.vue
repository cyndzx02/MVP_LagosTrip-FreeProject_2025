<template></template>

<script>
import tilapia from "../assets/tilapia.png"
import Porkmeat from "../assets/Porkmeat.png"
import banane from "../assets/banane.png"
import freshmeat from "../assets/fresh_meat.png"
import poisson from "../assets/poisson.png"
import tomato from "../assets/tomato.png"
</script>

<style></style>